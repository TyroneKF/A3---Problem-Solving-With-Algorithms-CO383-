import java.util.Scanner;


/**
 * Model a stack with push/pop operations.
 * A nested class, Node, is used to implement
 * the linking structure.
 *
 * @author David J. Barnes
 * @version 2020.02.14
 */
class submission1 {

    public static void main(String[] args)
    {   
        Stack secondStack = new Stack();

        boolean continuing = true;
        String currentNodeValue;
        int test;

        Scanner scanner = new Scanner(System.in); 
        do
        {   
            try
            {
                String entry = scanner.nextLine();
                String[] numbersAndOp = entry.split("\\s+");

                for (int i=numbersAndOp.length-1; i >=0; i-- )
                {   
                    currentNodeValue =numbersAndOp[i] ;

                    if(currentNodeValue.equals("+") || currentNodeValue.equals("-") ||currentNodeValue.equals("x"))
                    {   //System.out.println("Found Symbol");
                        secondStack.calculationOp(currentNodeValue);
                    }
                    else
                    {   try{
                            test = Integer.parseInt(currentNodeValue);
                            secondStack.push(currentNodeValue);                                
                        }
                        catch(Exception e)
                        {
                            continuing=false;
                            break;
                        }
                    }                    
                    if(i == 0)
                    {                        
                        System.out.println(secondStack.getTopValue());                            
                        continuing = false;   
                        break;
                    }                    

                }

            }
            catch(Exception e)
            {
                System.out.println("Error in main loop" + e);
            }

        }while(continuing);

    }

    public static class Stack
    {   

        // Top of the stack.
        private Node top;
        private int stackSize  = 0;
        /**
         * Constructor for objects of class CopyOfStack
         */
        public Stack()
        {
            top = null;
            stackSize = 0;
        }      

        public int stackSizeMethod()
        {
            return stackSize;
        }

        /**
         * Push a new value onto the stack.
         * @param value The value to be pushed.
         */
        public void push(String value)
        {
            stackSize ++;
            top = new Node(value, top);

        }

        /**
         * Pop (and return) the value on the top of the stack.
         * @return the value on the top of the stack.
         * @throws IllegalStateException if the stack is empty.
         */
        public String pop()
        {
            if(top != null) {
                String value = top.getValue();
                top = top.getNext();
                return value;                            
            }
            else 
            {
                throw new IllegalStateException("pop() called on an empty stack.");
            }
        }

        public void calculationOp(String symbol)
        {   
            try{
                if(top != null) 
                {   
                    int result = 0;
                    Node topNode = top;
                    Node nextNode = topNode.getNext();

                    int topNodeValue = Integer.valueOf(topNode.getValue());
                    int nextNodeValue = Integer.valueOf(topNode.getNext().getValue());
                    try
                    {
                        switch(symbol)
                        {
                            case "+": result = topNodeValue + nextNodeValue; break;
                            case "-": result = topNodeValue - nextNodeValue;break;
                            case "x": result = topNodeValue * nextNodeValue;break;
                            case "/": result = topNodeValue / nextNodeValue;break;
                        }

                        top = nextNode;
                        top.setValue(String.valueOf(result));
                        stackSize -= 1;
                    }
                    catch(Exception e)
                    {
                        System.out.println("\nCalculation Error" + "\n"+ e);
                    }
                }
                else
                {
                }
            }
            catch(Exception e)
            {
                System.out.println("\nOp Error" + "\n"+ e);
            }           
        }

        /**
         * Is the stack empty.
         * @return true if the stack is empty, false otherwise.
         */
        public boolean isEmpty()
        {  
            if(top == null)
            {
                return  true;
            }
            return false;
        }

        public String getTopValue()
        {
            return top.getValue();
        }

        public Node getTopNode()
        {
            return top;
        }

        public void getAllNodesValue()
        {   
            boolean go = true;
            boolean loop = true;
            Node currentNode = top;

            do 
            {   try
                { 
                    if(isEmpty()!= true)
                    {   
                        while(loop){
                            System.out.println(currentNode.getValue());
                            if(currentNode.hasNext())
                            {
                                currentNode = currentNode.getNext();
                            }
                            else
                            {   loop =false;
                                go = false;
                                break; 
                            }
                        }
                    }
                    else
                    {
                        System.out.println("Empty Stack");
                    }
                }
                catch(Exception e)
                {
                    System.out.println("Get all node printing error "+e);
                    go = false;
                    break;
                }
            }while(go);
        }

        /**
         * Linked Node class to store a single element of
         * the stack and a link to the item immediately below
         * it on the stack.
         */
        private class Node
        {
            private String value;
            private Node next;
            private int posInStack;
            /**
             * Create a new node on the top of the stack.
             * Link it to the node below it.
             * @param value The value pushed on the stack.
             * @param oldTop The previous top of stack.
             */
            public Node(String value, Node oldTop)
            {
                this.value = value;
                this.next = oldTop;
                posInStack = stackSize;
            }

            public void setValue(String value)
            {
                this.value= value;
            }

            int getPosInStack()
            {
                return posInStack;
            }

            /**
             * Get the value in this node.
             * @return the value.
             */
            String getValue()
            {
                return value;
            }

            /**
             * Get the next item in the stack.
             * @return the next item.
             */
            Node getNext()
            {
                return next;
            }

            boolean hasNext()
            {   
                if (next!=null)
                {
                    return true;
                }
                else{
                    return false;}
            }
        }
    }
}

